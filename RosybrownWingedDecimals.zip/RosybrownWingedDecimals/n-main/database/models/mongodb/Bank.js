// models/Bank.js
const mongoose = require('mongoose');

const bankSchema = new mongoose.Schema({
  userID: { type: String, required: true, unique: true },
  bank: { type: Number, default: 0 },
  lastInterestClaimed: { type: Number, default: 0 },
  loan: { type: Number, default: 0 },
  loanPayed: { type: Boolean, default: true }
});

module.exports = mongoose.model('Bank', bankSchema);