module.exports = {
 config: {
 name: "file",
 version: "1.0",
 author: "OtinXShiva",
 countDown: 5,
 role: 2,
 shortDescription: "Send bot script",
 longDescription: "Send bot specified file",
 category: "owner",
 guide: "{pn} file name. Ex: .{pn} filename"
 },

 onStart: async function ({ api, event, globalData, message, args }) {
 const vipMembers = await globalData.get("vipMembers", "data", []);
 const senderID = event.senderID;
 
 if (!vipMembers.includes(senderID)) {
 return message.reply("❌ | You do not have permission to use this command.");
 }

 const fs = require('fs');
 const fileName = args[0];
 
 if (!fileName) {
 return api.sendMessage("Please provide a file name.", event.threadID, event.messageID);
 }

 const filePath = __dirname + `/${fileName}.js`;
 if (!fs.existsSync(filePath)) {
 return api.sendMessage(`File not found: ${fileName}.js`, event.threadID, event.messageID);
 }

 const fileContent = fs.readFileSync(filePath, 'utf8');
 api.sendMessage({ body: fileContent }, event.threadID);
 }
};